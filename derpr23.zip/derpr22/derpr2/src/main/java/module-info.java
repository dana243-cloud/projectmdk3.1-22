module com.example.derpr2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.derpr2 to javafx.fxml;
    exports com.example.derpr2;
}