package com.example.derpr2;

public class ShapeFactory {
    public static ShapeProduct createShape(String type) {
        return switch (type.toLowerCase()) {
            case "круг" -> new CircleProduct();
            case "линия" -> new LineProduct();
            case "прямоугольник" -> new RectangleProduct();
            default -> null;
        };
    }
}